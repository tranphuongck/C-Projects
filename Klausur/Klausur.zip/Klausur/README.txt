Platzieren Sie das Verzeichnis "Klausur" in Ihr Übungsverzeichnis für Programmieren 1. Es sollte sich im gleichen Verzeichnis befinden, wie die Verzeichnisse für die Übungen und das Verzeichnis prog1lib.

